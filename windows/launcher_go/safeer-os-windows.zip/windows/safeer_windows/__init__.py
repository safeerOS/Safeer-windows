"""Safeer Browser for Windows."""
